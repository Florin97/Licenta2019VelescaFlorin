package com.florinvelesca.beaconapp.interfaces;

import java.util.List;

public interface GetRegisteredBeaconNames {
    void getRegisteredNames(List<String> names);
}

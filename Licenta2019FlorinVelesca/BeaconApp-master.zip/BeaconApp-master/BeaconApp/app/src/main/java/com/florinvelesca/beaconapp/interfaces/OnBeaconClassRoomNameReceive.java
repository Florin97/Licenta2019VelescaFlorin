package com.florinvelesca.beaconapp.interfaces;

import com.florinvelesca.beaconapp.database.BeaconTable;

public interface OnBeaconClassRoomNameReceive {
    void OnBeaconNameRetrieve(BeaconTable name);
}

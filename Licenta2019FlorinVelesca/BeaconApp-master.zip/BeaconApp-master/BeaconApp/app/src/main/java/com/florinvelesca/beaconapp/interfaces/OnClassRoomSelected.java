package com.florinvelesca.beaconapp.interfaces;

public interface OnClassRoomSelected {
     void onClassSelected(int position);
}
